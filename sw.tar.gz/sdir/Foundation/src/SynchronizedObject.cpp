//
// SynchronizedObject.cpp
//
// Library: Foundation
// Package: Threading
// Module:  SynchronizedObject
//
// Copyright (c) 2004-2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/SynchronizedObject.h"


namespace Poco {


SynchronizedObject::SynchronizedObject()
{
}

	
SynchronizedObject::~SynchronizedObject()
{
}


} // namespace Poco
